finalStep = stepFactory.createStep()

finalStep.run = {
	println "finalStep.run"
  g.V.filter{it.active}.each { player->
    player.text = c.get("FinalStep")
    a.add(player, [name: "Submit",
    custom: """
      <div>
<input type="number" name="textinput" min="1" max="12" step="1" ng-init ="textinput=5" class="param" ng-model="textinput" required>
</div>
    """,
    result: { params->
      println(params)
      player.final = params.textinput
      a.addEvent("finalChoice",["pid":player.id,
	 "choice":player.final]) 
    player.text += "<p>Please wait for the other players to make their choices.</p>"
    }])
  }
}

finalStep.done = {
	println "finalStep.done"
  def fail = "false"
  def finalCol = []
  g.V.filter{it.active}.each { player->
      finalCol << player.final
    }
  
  if(finalCol.unique().size() > 1){
   fail ="true" 
  }
  
  	g.V.filter{it.active}.each { player->
      if(fail == "true"){
      player.text = c.get("Finished", "Lost!", "Your payment is \$3")
      a.addEvent("gameEnd",[
	 "Result":"Failure"])
      g.getSubmitForm(player, 2, true)
      }
      else{
        player.text = c.get("Finished", "Won!", "Your payment is \$6")
        a.addEvent("gameEnd",[
	 "Result":"Success"])
        g.getSubmitForm(player, 5, true)
      }
    }
}

