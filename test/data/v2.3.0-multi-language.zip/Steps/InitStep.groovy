// Global variables
curRound = 0

initStep = stepFactory.createStep()

initStep.run = {
  println "initStep.run: ${curRound}"
  //g.addVertices(20)
  //g.V.each{player->
  
    //if(player.id != "Stan"){
    // a.ai.add(player) 
    //}
  
  //}
  if(g.V.count() > 5){
   g.wattsStrogatz(2,0.9)
  }
  
  curRound = 1
  // Start dropping players
  a.setDropPlayers(true)
  
  g.V.filter{it.active != null}.each { player->
    if(player.Q3 !="a" || player.Q2 != "b" || player.Q1 !="c"){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
  	a.remove(player.id)  
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
    player.quiz = false
  }    
    else{
    player.quiz = true
    }
  
  }
  
  g.V.filter{it.active}.each { player->
    player.show =""
    player.text = c.get("PleaseWait") + "<p><strong>Click 'Begin' to join the game.</strong></p>"
    a.add(player, [name: "Begin", result: {
      player.text = c.get("PleaseWait") + "<p><strong>Thank you, the game will begin in a moment.</strong></p>"
    }])
  }
}

initStep.done = {
  println "initStep.done: ${curRound}"
  messageStep.start()
}