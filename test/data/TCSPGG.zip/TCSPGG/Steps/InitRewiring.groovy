def initRewiring(player, neighbor, connected) {

  /* Fills for RewiringStep are:
  *  {0} = '_' or 'not'
  *  {1} = 'cut the' or 'make a'
  *  {2} = neighbor.cooperation
  *  {3} = neighbor.score
  *  {4} = 'chose A and gave points'/'chose B and did not give points'
  *  {5} = 'The current score of this player is #.'/""
  */
    
  def init = {    
    // Set up the fills
    def fill0 = (connected) ? "" : "not "
    def fill1 = (connected) ? "<span class=\"break\">cut the connection</span>" : "<span class=\"make\">make a connection</span>"
    def fill3 = (showScore) ? neighbor.score : "" 
    def fill4 = "This player has not yet made a choice to give points to others."
    if (neighbor.cooperation == 1) {
      fill4 = "This player <span class=\"orange\">chose A</span> and gave points to others in the last step."
    } else if (neighbor.cooperation == -1) {
      fill4 = "This player <span class=\"blue\">chose B</span> and did not give points to others in the last step."
    }
    def fill5 = (showScore) ? "<p>The current score of this player is <strong>" + neighbor.score + "</strong>.</p>" : ""

    // Set player text with fills
    player.text = c.get("RewiringStep", fill0, fill1, neighbor.cooperation, fill3, fill4, fill5)

    if (practice) {
      player.text = c.get("PracticeRound", curRound, practiceRounds) + player.text
    }
    
    if (connected) {
      def e = g.getEdge(player, neighbor)
      e.private(player, ["active":1, "breaking":1])
    } else {
      // Display a temporary edge to the deciding, if it hasn't already been created
      def tempEdge = g.getEdge(player, neighbor)
      if (tempEdge != null) {
        tempEdge.private(player, ["hidden":0, "making":1, "active":1])
      } else {
        println("tempEdge == null")
      }
    }
  }
                
  a.add(player, init,
    [name: (connected) ? "Cut" : "Make", 
    event: [
      name: "rewiringEvent",
      data: [
        round:  (practice) ? "p" + curRound : curRound,
        action: (connected) ? "breakConnection" : "makeConnection",
        pid: player.id,
        nid: neighbor.id
      ]
    ],
    result: {
      def e = g.getEdge(player, neighbor)
      if (e == null) {
        println("e == null, initRewiring, Yes")
      }
      if (connected) {
        // Unilateral breaking        
        e.breaking = neighbor.id
        e.private(player, ["arrow":neighbor.id + ",red", "breaking":1, "active":-1])
        player.playerBreakConnections += 1
        neighbor.neighborBreakConnections += 1
      } else {
        // Bilateral making
        e.private(player, ["active":-1, "making":1, "arrow":neighbor.id + ",green"])
        e.creating[player.id] = 1
      }
      player.text = player.text + c.get("PleaseWait")

    }],
    [name: (connected) ? "Do not cut" : "Do not make", 
    event: [
      name: "rewiringEvent",
      data: [
        round:  (practice) ? "p" + curRound : curRound,
        action: "maintainConnection",
        pid: player.id,
        nid: neighbor.id
      ]
    ],
    result: {
      def e = g.getEdge(player, neighbor)
      if (e == null) {
        println("e == null, initRewiring, No")
      }
      if (connected) {
        e.private(player, ["breaking":0, "arrow":"", "active":-1])
      } else {
        e.private(player, ["hidden":1])
        e.creating[player.id] = -1
      }
      player.text =  player.text + c.get("PleaseWait")

    }])
}