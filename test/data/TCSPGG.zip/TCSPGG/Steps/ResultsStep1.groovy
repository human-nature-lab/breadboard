resultsStep1 = stepFactory.createStep("Results1")

resultsStep1.run = {
  println("resultsStep1.run: " + curRound)
  curStep = "results1"
  
  // Results Step 1: Show effect of Player's choice on neighbors
  // Animate +coc travelling from player to neighbors
    
  g.V.filter{it.active == true}.each { player->
    // Show neighbors' change to score
    if (showScore) {  player.score = player.private.score  }
    // At this point the players' scores only reflect the coc paid in the cooperation round
  }
  
  g.V.filter{it.active == true}.each { player->
    def totalNeighbors = player.neighbors.count()
    def playerPaid = 0
    def playerContributed = 0
    
    def coopNeighbors = player.neighbors.filter({it.private.cooperation == 1}).count()
    def neighborsContributed = coopNeighbors * po
    
    if (showScore) { 
      player.score += neighborsContributed 
    } else {
      player.tempScore = player.private.score + neighborsContributed
    }
      
    if (player.private.cooperation == 1) {
      // Animate the effect of their cooperation
      player.neighbors.each { neighbor ->
        g.getEdge(player, neighbor).private(player, ["animate" : curRound + ",-" + coc + "," + player.getId() + "," + neighbor.getId()])
      }
      playerPaid = coc * totalNeighbors
      playerContributed = po
    }
                
    player.text = c.get("ResultsStep1", playerPaid, playerContributed)
    
    if (practice) {
      player.text = c.get("PracticeRound", curRound, practiceRounds) + player.text
    }
       
    a.add(player, [name: "Next", result: { 
    	player.text = player.text + c.get("PleaseWait")
    }])
  }
}

resultsStep1.done = {
  g.E.each { edge ->
  	edge.inProps.animate = ""
    edge.outProps.animate = ""
  }
  
  println("resultsStep1.done: " + curRound)  
  resultsStep2.start()
}