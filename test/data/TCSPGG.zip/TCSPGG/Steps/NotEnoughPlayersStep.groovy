notEnoughPlayersStep = stepFactory.createStep("NotEnoughPlayers")

notEnoughPlayersStep.run = {
  curStep = "notEnoughPlayers"
  // Remove any outstanding actions
  a.empty()
  g.V.each { player->
    player.timer = ""
    player.text = c.get("NotEnoughPlayers")
  }
}

notEnoughPlayersStep.done = {
	println "notEnoughPlayersStep.done"
}