resultsStep2 = stepFactory.createStep("Results2")

resultsStep2.run = {
  println("resultsStep2.run: " + curRound)
  curStep = "results2"
  
  g.V.filter{it.active == true}.each { player->
    // Show neighbors' choices
    player.cooperation = player.private.cooperation    
  }
  
  g.V.filter{it.active == true}.each { player->
    // Now set private.score = score
    if (showScore) {
      player.private.score = player.score
    } else {
      player.private.score = player.tempScore
    }
    
    a.addEvent("currentScore", 
    ["pid" : player.id,
     "round": (practice) ? "p" + curRound : curRound,
     "score" : player.private.score])
    
    // Calculate change in score
    def coopNeighbors = player.neighbors.filter({it.cooperation == 1}).count()
    def neighborsContributed = coopNeighbors * po
     
    player.neighbors.each { neighbor ->
      if (neighbor.cooperation == 1) {
        g.getEdge(player, neighbor).private(player, ["animate" : curRound + "," + po + "," + neighbor.getId() + "," + player.getId()])
      }
    }              
    
    player.text = c.get("ResultsStep2", coopNeighbors, coc, neighborsContributed)
    
    if (practice) {
      player.text = c.get("PracticeRound", curRound, practiceRounds) + player.text
    }
        
    a.add(player, [name: "Submit", 
                   custom: """
<p><strong>How do you feel right now?</strong></p>
<input required class="param" type="radio" name="satisfaction" value="v_good"> Very Good<br>
<input required class="param" type="radio" name="satisfaction" value="good"> Good<br>
<input required class="param" type="radio" name="satisfaction" value="neutral"> Neutral<br>
<input required class="param" type="radio" name="satisfaction" value="bad"> Bad<br>
<input required class="param" type="radio" name="satisfaction" value="v_bad"> Very Bad<br>
                           """,
                   result: { params->
                     if (params != null && params.containsKey("satisfaction")) {
                       println(params)
                       a.addEvent("reportSatisfaction", 
                                 ["pid": player.id, 
                                  "step": "cooperationResults",
                                  "round": (practice) ? "p" + curRound : curRound, 
                                  "satisfaction" : params.satisfaction])
                     }
    	             player.text = player.text + c.get("PleaseWait")
                   }])
  }
}

resultsStep2.done = {
  g.E.each { edge ->
  	edge.inProps.animate = ""
    edge.outProps.animate = ""
  }
  println("resultsStep2.done: " + curRound)  
  rewiringStep.start()
}