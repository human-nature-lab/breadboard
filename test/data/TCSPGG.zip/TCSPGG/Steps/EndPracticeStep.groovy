endPracticeStep = stepFactory.createStep("EndPractice")

endPracticeStep.run = {
  println("endPracticeStep.run: " + curRound)
  curStep = "endPractice"
  practice = false
  
  def dummyVertices = g.V.filter({ v-> v.dummy != null }).toList()
  dummyVertices.each { 
    g.removePlayer(it.getId()) 
  }
  
  // Drop dropped players at end of Practice Rounds
  g.V.filter({ v-> v.dropped == true }).each { droppedPlayer->
    dropPlayer(droppedPlayer)
  }

  curRound = 1
  g.V.filter{it.active == true}.each { player ->
    
    player.cooperation = 0
    player.private.cooperation = 0
   
    if (r.nextDouble() < percentA) {
      player.group = "A"
      player.private.score = scoreA
    } else {
      player.group = "B"
      player.private.score = scoreB
    }
    
    a.addEvent("InitialScore", [pid : (player.id), score : player.private.score])

    player.text = c.get("EndPracticeStep", player.private.score)
        
    if (showScore) { player.score = player.private.score }
    
    a.add(player, [name: "Next", result: { 
    	player.text =  player.text + c.get("PleaseWait")
    }])
  }
}

endPracticeStep.done = {
  println("endPracticeStep.done: " + curRound)
  endPracticeStep2.start()
}