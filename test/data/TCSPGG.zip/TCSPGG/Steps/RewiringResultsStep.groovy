rewiringResultsStep = stepFactory.createStep("RewiringResults")

rewiringResultsStep.run = {
  println("rewiringResultsStep.run: " + curRound)
  curStep = "rewiringResults"

  /* Fills for RewiringStep are:
  *  {0} = # agreeAgreeMakeConnections
  *  {1} = # agreeDisagreeMakeConnections
  *  {2} = # disagreeDisagreeMakeConnections
  *  {3} = # disagreeAgreeMakeConnections
  *  {4} = # playerBreakConnections
  *  {5} = # neighborBreakConnections
  */
  
  // Make it appear like dropped players break all connections with their neighbors
  g.V.filter({ v-> v.dropped == true }).each { droppedPlayer->
    droppedPlayer.both.each { neighbor ->
      neighbor.neighborBreakConnections += 1
      g.getEdge(droppedPlayer, neighbor).breaking = neighbor.id
    }
  }
  
  // Process and show unilateral edge breaking results
  g.E.hasNot("breaking", null).each { edge ->
    def edgeVertices = edge.bothV.toList()
    def v1 = edgeVertices.get(0)
    def v2 = edgeVertices.get(1)
    edge.private(v1, ["arrow":edge.breaking + ",red", "breaking":1, "making":0, "active":0])
    edge.private(v2, ["arrow":edge.breaking + ",red", "breaking":1, "making":0, "active":0])
    edge.breaking = 1
  }
  
  // Process and show bilateral edge creation results
  g.E.has("breaking", null).has("isNew", true).each { edge ->
    edge.isNew = false
    def edgeVertices = edge.bothV.toList()
    def v1 = edgeVertices.get(0)
    def v2 = edgeVertices.get(1)

    def toBreak = true

    if (edge.creating[v1.id] == 1 && edge.creating[v2.id] == 1) {
      // Both chose 'Yes'
      edge.private(v1, ["making":1,"hidden":0,"arrow":"both,green","active":0])
      edge.private(v2, ["making":1,"hidden":0,"arrow":"both,green","active":0])
      v1.agreeAgreeMakeConnections += 1
      v2.agreeAgreeMakeConnections += 1
      toBreak = false
    } else if (edge.creating[v1.id] == 1 && edge.creating[v2.id] == -1) {
      // v1 chose 'Yes', v2 chose 'No'
      edge.private(v1, ["making":0,"hidden":1,"arrow":""])
      edge.private(v2, ["making":0,"hidden":1,"arrow":""])
      v1.agreeDisagreeMakeConnections += 1
      v2.disagreeAgreeMakeConnections += 1
    } else if (edge.creating[v1.id] == -1 && edge.creating[v2.id] == 1) {
      // v2 chose 'Yes', v1 chose 'No'
      edge.private(v1, ["making":0,"hidden":1,"arrow":""])
      edge.private(v2, ["making":0,"hidden":1,"arrow":""])
      v2.agreeDisagreeMakeConnections += 1
      v1.disagreeAgreeMakeConnections += 1
    } else {
      // Both chose 'No'
      edge.private(v1, ["making":0,"hidden":1,"arrow":""])
      edge.private(v2, ["making":0,"hidden":1,"arrow":""])
      v1.disagreeDisagreeMakeConnections += 1
      v2.disagreeDisagreeMakeConnections += 1
    }

    if (toBreak) {
      edge.breaking = 1
    }
  }


  g.V.filter{it.active == true}.each { player->
    def b0 = (player.agreeAgreeMakeConnections > 0)
    def b1 = (player.agreeDisagreeMakeConnections > 0)
    def b2 = (player.disagreeDisagreeMakeConnections > 0)
    def b3 = (player.disagreeAgreeMakeConnections > 0)
    def b4 = (player.playerBreakConnections > 0)
    def b5 = (player.neighborBreakConnections > 0)

    def fill0 = (b0) ? "<li>you and " + player.agreeAgreeMakeConnections + " player(s) agreed to make a new connection</li>" : ""
    def fill1 = (b1) ? "<li>you attempted to make " + player.agreeDisagreeMakeConnections + " new connection(s) but the player(s) disagreed</li>" : ""
    def fill2 = (b2) ? "<li>you and " + player.disagreeDisagreeMakeConnections + " player(s) decided not to make new connections</li>" : ""
    def fill3 = (b3) ? "<li>" + player.disagreeAgreeMakeConnections + " player(s) attempted to make new connection(s) but you disagreed</li>" : ""
    def fill4 = (b4) ? "<li>you broke " + player.playerBreakConnections + " connection(s) with player(s)</li>" : ""
    def fill5 = (b5) ? "<li>" + player.neighborBreakConnections + " player(s) broke their connection(s) with you</li>" : ""
    def fill6 = (b0 || b1 || b2 || b3 || b4 || b5) ? "" : "<li>There were no changes to your connections this round.</li>"

    player.text = c.get("RewiringResultsStep", fill0, fill1, fill2, fill3, fill4, fill5, fill6)
    
    if (practice) {
      player.text = c.get("PracticeRound", curRound, practiceRounds) + player.text
    }

    if (happinessRewiring) {
      a.add(player, [name: "Submit", 
                     custom: """
  <p><strong>How do you feel right now?</strong></p>
  <input required class="param" type="radio" name="satisfaction" value="v_good"> Very Good<br>
  <input required class="param" type="radio" name="satisfaction" value="good"> Good<br>
  <input required class="param" type="radio" name="satisfaction" value="neutral"> Neutral<br>
  <input required class="param" type="radio" name="satisfaction" value="bad"> Bad<br>
  <input required class="param" type="radio" name="satisfaction" value="v_bad"> Very Bad<br>
                             """,
                     result: { params->
                       if (params != null && params.containsKey("satisfaction")) {
                         println(params)
                         a.addEvent("reportSatisfaction", 
                                   ["pid": player.id, 
                                    "step": "rewiringResults",
                                    "round": (practice) ? "p" + curRound : curRound, 
                                    "satisfaction" : params.satisfaction])
                       }
                       player.text = player.text + c.get("PleaseWait")
                     }])
    } else {
      a.add(player, [name: "Next", result: { 
          player.text = player.text + c.get("PleaseWait")
      }])
    }
  }
}


rewiringResultsStep.done = {
  println("rewiringResultsStep.done: " + curRound)
  
  g.E.has("breaking", 1).remove() 
  
  // Drop dropped players with 0 neighbors now
  g.V.filter({ v-> v.dropped == true }).each { droppedPlayer->
    if (droppedPlayer.neighbors.count() == 0) {
      //g.removePlayer(droppedPlayer.id)
      dropPlayer(droppedPlayer)
    }
  }
  
  g.V.filter{it.active == true}.each { player ->
    player.bothE.each { e ->
      e.private(player, [arrow:"", hidden:0, breaking:0, making:0, active:0])
    }
  }
  
  curRound++
  
  if (practice) {
    if (curRound > practiceRounds) {
      endPracticeStep.start()
    } else {
      cooperationStep.start()
    }
  } else {
    if (curRound <= nRounds) {
      g.V.filter{it.active == true}.each { player->
        player.curRound = curRound
      }
      cooperationStep.start()
    } else {
      finishedStep.start()
    }
  }
  
}