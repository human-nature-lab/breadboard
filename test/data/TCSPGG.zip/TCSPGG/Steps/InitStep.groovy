// Global variables
startAt = false
curRound = 0
curStep = "init"
practice = false
gameStarted = false
initStep = stepFactory.createStep("init")

initStep.run = {
  // Re-initialize global variables
  startAt = false
  curRound = 0
  curStep = "init"
  practice = false
  gameStarted = true
  // Now start dropping idle players
  a.setDropPlayers(true)
  a.setIdleTime(idleTime)
  a.setDropPlayerClosure({ player->
    player.dropped = true
    player.text = c.get("Dropped")
    a.ai.add(player)
    a.addEvent("AddAI", ["pid" : player.id])
  })
  
  if (curRound < practiceRounds) {
    practice = true
  } 
  
  // record initial parameters in data here
  a.addEvent("initParameters", 
    ["connectivity" : connectivity,
     "k" : k,
     "coc" : coc,
     "po" : po,
     "practiceScore" : practiceScore,
     "nRounds" : nRounds,
     "percentA" : percentA,
     "scoreA" : scoreA,
     "scoreB" : scoreB,
     "showScore" : showScore,
     "minPlayers" : minPlayers,
     "idleTime" : idleTime,
     "practiceRounds" : practiceRounds,
     "happinessRewiring" : happinessRewiring])
  
  curRound = 1
 
  if (g.V.filter({ v-> v.dummy == null }).toList().size() < minPlayers) {
    g.V.each { player ->
      player.text = c.get("NotEnoughPlayers")
    }
  } else {
    g.V.filter({ v-> v.dummy == null }).each { player ->
      def startButton = "Start Game"
      if (practice) {
  		startButton = "Start Practice Rounds"
  	  }
      
      a.add(player, [name: startButton, result: {
        player.active = true
        player.cooperation = 0
        player.private.cooperation = 0
        player.private.score = practiceScore
        def n1 = g.getVertex("dummy_" + player.id + "_1") 
        def n3 = g.getVertex("dummy_" + player.id + "_3") 
        def n4 = g.getVertex("dummy_" + player.id + "_4")
        n1.cooperation = 0
        n1.private.cooperation = 0
        n1.private.score = practiceScore
        n3.cooperation = 0
        n3.private.cooperation = 0
        n3.private.score = practiceScore
        n4.cooperation = 0
        n4.private.cooperation = 0
        n4.private.score = practiceScore
        if (showScore) { 
          player.score = player.private.score 
          n1.score = practiceScore
          n3.score = practiceScore
          n4.score = practiceScore
        }
        player.text =  player.text + "<h3>Please wait while the other players finish the tutorial. The game will start within 2 minutes.</h3>"
      }])
    }
  }
  println("initStep.run")
}

initStep.done = {
  println("initStep.done")
  if (g.V.filter{it.active == true}.toList().size() < minPlayers) {
    notEnoughPlayersStep.start()
  } else if (practice) {
    g.V.filter({v-> v.dummy != null}).each { dummyPlayer ->
      // Add AI to all dummy players
      a.ai.add(dummyPlayer)
    }
    
    cooperationStep.start()
  } else {
    endPracticeStep.start()
  }
}