def dropPlayer(player) {
  player.text = c.get("Dropped")
  player.getEdges(Direction.BOTH, "connected").each { removeEdge(it) }
  if (player.active != false) {
    a.addEvent("DropPlayer", ["pid" : player.id])
  }
  player.active = false
}
