rewiringStep = stepFactory.createStep("Rewiring")

rewiringStep.run = {
  println("rewiringStep.run: " + curRound)
  curStep = "rewiring"
  
  g.V.filter{it.active == true}.each { player->
    // Make all edges inactive
    player.bothE.each { edge ->
      edge.private(player, ["active":-1])
    }
    
    player.text = c.get("NoRewiring")
    
    if (practice) {
      player.text = c.get("PracticeRound", curRound, practiceRounds) + player.text
    }
    
    // Set up counts for rewiring results step
    player.agreeAgreeMakeConnections = 0
    player.agreeDisagreeMakeConnections = 0
    player.disagreeDisagreeMakeConnections = 0
    player.disagreeAgreeMakeConnections = 0
    player.playerBreakConnections = 0
    player.neighborBreakConnections = 0
    
    player.toggle = [:]
  }

  if (practice) {
    g.V.filter{it.active == true}.each { player ->
      def neighbors = g.V.filter({ v -> v.dummy == player.id }).toList()
      neighbors.each { n ->          
        if (r.nextDouble() < k) {
          def connected = g.hasEdge(player, n)
          if (! connected) {
            // Create temporary edge to show possible edge
            def tempEdge = g.addEdge(player, n, "connected")
        	tempEdge.private(n, ["hidden":0,"making":1,"active":-1])
            tempEdge.private(player, ["hidden":0,"making":1,"active":-1])
            tempEdge.creating = [:]
            tempEdge.isNew = true
          } else {
            // Mark the connected edge as breaking for choosing player
            def breakingEdge = g.getEdge(player, n)
            breakingEdge.private(player, ["breaking":1])
          }
          
          initRewiring(player, n, connected)
          if (! connected) {
            initRewiring(n, player, connected)
          }
        }
      }
    }
  } else {
    List players = g.V.filter{it.active == true}.toList()
    for (int i = 0; i < (players.size() - 1); i++) { 
      for (int j = (i + 1); j < players.size(); j++) { 
        if (r.nextDouble() < k) {
          def player = players.get(i)
          def neighbor = players.get(j)
          if (r.nextDouble() < 0.5) {
            // Pick a random node to be the player
            player = players.get(j)
            neighbor = players.get(i)
          }
          def connected = g.hasEdge(player, neighbor)

          if (! connected) {
            // Create temporary, hidden, edge
            def tempEdge = g.addEdge(player, neighbor, "connected")
            tempEdge.private(neighbor, ["hidden":0,"making":1,"active":-1])
            tempEdge.private(player, ["hidden":0,"making":1,"active":-1])
	        tempEdge.creating = [:]
            tempEdge.isNew = true
            initRewiring(neighbor, player, connected)
          } else {
            // Mark the connected edge as breaking for choosing player
            def breakingEdge = g.getEdge(player, neighbor)
            breakingEdge.private(player, ["breaking":1])
          }
        
          // Always initRewiring for the player
          initRewiring(player, neighbor, connected)
        
        } // END if (r.nextDouble() < k)
      } // END for (j in i+1..(players.size()-1))
    } // END for (i in 0..(players.size()-2))
  } // END if (practice)

} // END rewiringStep.run

rewiringStep.done = {
  println("rewiringStep.done: " + curRound)
  rewiringResultsStep.start()
}