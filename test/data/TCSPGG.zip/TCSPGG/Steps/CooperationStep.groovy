cooperationStep = stepFactory.createStep("Cooperation")

cooperationStep.run = {
  println("cooperationStep.run: " + curRound)
  curStep = "cooperation"
  g.V.filter{it.active == true}.each { player->
    
    if (player.neighbors.count() == 0) {
      player.text = c.get("CoopNoRewiringStep", coc, po)
    } else {
      player.text = c.get("CooperationStep", coc, po)
        
      a.add(player, {},  
        [name: "A (-" + (coc * player.neighbors.count()) + ")",
         class: "coopButton orange", 
         event: [
           name: "cooperationEvent",
           data: [
             round: (practice) ? "p" + curRound : curRound,
             action: "cooperate",
             pid: player.id
           ]
         ],
         result: {
           player.private.cooperation = 1
           player.private.score -= (coc * player.neighbors.count())
           player.text =  player.text + c.get("PleaseWait")
         }], 
        [name: "B (0)",
         class: "coopButton blue",
         event: [
           name: "cooperationEvent",
           data: [
             round: (practice) ? "p" + curRound : curRound,
             action: "defect",
             pid: player.id
           ]
         ],
         result: {
           player.private.cooperation = -1
           player.text =  player.text + c.get("PleaseWait")
         }])
    }
    
    if (practice) {
      player.text = c.get("PracticeRound", curRound, practiceRounds) + player.text
    }  

  }
}

cooperationStep.done = {
    println("cooperationStep.done: " + curRound)
    resultsStep1.start()
}