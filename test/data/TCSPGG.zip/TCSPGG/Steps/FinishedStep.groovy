finishedStep = stepFactory.createStep("Finished")

finishedStep.run = {
  curStep = "finished"
  
  g.V.filter{it.active == true}.each { player->
    a.addEvent("FinalScore", [(player.id) : player.private.score])
    
    player.text = c.get("Survey")
    
    if (! player.id.contains("_")) {
      a.add(player, q1(player))
      a.add(player, q2(player))
      a.add(player, q3(player))
      a.add(player, q4(player))
      a.add(player, q5(player))
      a.add(player, q6(player))
      a.add(player, q7(player))
      a.add(player, q8(player))
      a.add(player, q9(player))
      a.add(player, k6_1(player))
      a.add(player, k6_2(player))
      a.add(player, k6_3(player))
      a.add(player, k6_4(player))
      a.add(player, k6_5(player))
      a.add(player, k6_6(player))
      a.add(player, q10(player))
      a.add(player, q11(player))
      a.add(player, q12(player))
      a.add(player, 
            { player.text = c.get("SurveyDone") }, 
            [name: "Done", 
             result: {
              def dollars = (player.private.score < 0) ? 0 : player.private.score / 1000
              //def submitForm = "<form action=\"https://www.mturk.com/mturk/externalSubmit\" method=\"get\"><button type=\"submit\">Submit HIT</button> <input type=\"hidden\" name=\"assignmentId\" value=\"" + player.id + "\" /> <input type=\"hidden\" name=\"bonus\" value=\"" + dollars + "\" /></form>"
              player.text = c.get("FinishedStep", dollars)
             }])
    }
  }
}

finishedStep.done = {
  println("done")
}