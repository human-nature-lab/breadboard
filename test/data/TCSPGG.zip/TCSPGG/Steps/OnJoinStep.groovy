onJoinStep = stepFactory.createNoUserActionStep()

onJoinStep.run = { playerId ->
  a.setIdleTime(idleTime)
  if (playerId) {
  	def player = g.getVertex(playerId)
    println("got here 1:" + playerId) 
    // Validation to prevent players from joining
    // an existing round
    if (gameStarted)  {
      dropPlayer(player)
    } else {   
      //if (! player.dummy) {
      if (! playerId.contains("dummy") && player != null) {
        // Set up counts for rewiring results step
        player.agreeAgreeMakeConnections = 0
        player.agreeDisagreeMakeConnections = 0
        player.disagreeDisagreeMakeConnections = 0
        player.disagreeAgreeMakeConnections = 0
        player.playerBreakConnections = 0
        player.neighborBreakConnections = 0    
        player.tutorialCompleted = false
        player.toggle = [:]
        //Timer setup to start a game
        def curTime = new Date().getTime()
        if (!startAt) {
          startAt = curTime + 1000000
        }
        g.addTimer("player": player, time: ((startAt - curTime)/1000).toInteger(), type: "time", appearance: "info", timerText: "The game will start in:", direction: "down", result: {})
        player.private.score = practiceScore
        player.cooperation = 0
        player.private.cooperation = 0
        def neighborScore = (showScore) ? practiceScore : ""
        
        player.text = c.get("Tutorial", practiceScore)
        
        // Tutorial 1
        a.add(player, [name: "Next", result: {        
          for (i in 1..6) {
            def dummyPlayer = g.addVertex("dummy_" + playerId + "_" + i)
            //def dummyPlayer = g.getVertex("dummy_" + playerId + "_" + i)
            dummyPlayer.dummy = player.id
            dummyPlayer.active = true
            dummyPlayer.text = ""          
            dummyPlayer.private.score = practiceScore
            if (showScore) {
              dummyPlayer.score = practiceScore
            }
            
            if (i < 4) {
              dummyPlayer.cooperation = 0
              dummyPlayer.private.cooperation = 0
              g.addEdge(dummyPlayer, player, "connected")
            } else {
              if (i < 6) {
                dummyPlayer.cooperation = 1
                dummyPlayer.private.cooperation = 1
              } else {
                dummyPlayer.cooperation = -1
                dummyPlayer.private.cooperation = -1
              }
            }
            println("got here 2:" + dummyPlayer.id)
          }
          println("got here 3:" + playerId)
          player.text = c.get("Tutorial1", neighborScore)
        }])
        
        // Tutorial 2
        a.add(player, [name: "Next", result: {  
          player.text = c.get("Tutorial2")
        }])
        
        // Tutorial 3 - Player cooperates      
        a.add(player, [name: "Next", result: {  
          player.text = c.get("Tutorial3", coc, po)
        }])
        
        // Tutorial 3 Results - Player cooperates results 1
        a.add(player, {},  
          [name: "Next",
           result: {
             player.private.cooperation = 1
             def playerPaid = (coc * player.neighbors.count())
             player.private.score -= playerPaid
             player.neighbors.each { neighbor ->
               if (showScore) {
                 neighbor.score += po
               }
               g.getEdge(player, neighbor).private(player, ["animate" : "T3R1" + ",-" + coc + "," + player.getId() + "," + neighbor.getId()])
             }
             player.text = c.get("TutorialResults1", playerPaid,po)
        }])
        
        // Tutorial 3 Results - Player cooperates results 2      
        a.add(player, [name: "Next", result: {
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2") 
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          
          n1.cooperation = 1
          n1.private.cooperation = 1
          n2.cooperation = -1
          n2.private.cooperation = -1
          n3.cooperation = 1
          n3.private.cooperation = -1
          
          if (showScore) {
            n1.score -= coc
            n3.score -= coc
          }
          
          g.getEdge(player, n1).private(player, ["animate" : "T3R2" + "," + po + "," + n1.getId() + "," + player.getId()])
          g.getEdge(player, n2).private(player, ["animate" : ""])
          g.getEdge(player, n3).private(player, ["animate" : "T3R2" + "," + po + "," + n3.getId() + "," + player.getId()])
          
          player.private.score += (po * 2)

          player.text = c.get("TutorialResults2", 2, coc, (po * 2))
        }])
        
        // Tutorial 3 - Player defects      
        a.add(player, [name: "Next", result: { 
          // Reset the neighbors to grey and their points to default
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2")
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          
          n1.cooperation = 0
          n1.private.score = practiceScore
          n2.cooperation = 0
          n1.private.score = practiceScore
          n3.cooperation = 0
          n1.private.score = practiceScore
          
          if (showScore) {
            n1.score = n1.private.score
            n2.score = n2.private.score
            n3.score = n3.private.score
          }
          
          // Reset player
          player.private.cooperation = -1
          player.private.score = practiceScore

          g.getEdge(player, g.getVertex("dummy_" + playerId + "_1")).private(player, ["animate" : ""])
          g.getEdge(player, g.getVertex("dummy_" + playerId + "_3")).private(player, ["animate" : ""])

          player.text = c.get("TutorialResults3")
        }])
            
        // Tutorial 3 Results - Player defects results 2      
        a.add(player, [name: "Next", result: {
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2") 
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          
          n1.cooperation = 1
          n1.private.cooperation = 1
          n2.cooperation = -1
          n2.private.cooperation = -1
          n3.cooperation = 1
          n3.private.cooperation = 1
          
          if (showScore) {
            n1.score -= coc
            n3.score -= coc
          }
          
          g.getEdge(player, n1).private(player, ["animate" : "T4R2" + "," + po + "," + n1.getId() + "," + player.getId()])
          g.getEdge(player, n2).private(player, ["animate" : ""])
          g.getEdge(player, n3).private(player, ["animate" : "T4R2" + "," + po + "," + n3.getId() + "," + player.getId()])
                  
          player.private.score += (po * 2)

          player.text = c.get("TutorialResults2", 2, coc, (po * 2))
        }])
                
        // Tutorial 4 - Rewiring description   
        a.add(player, [name: "Next", result: { 
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2") 
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          
          g.getEdge(player, n1).private(player, ["animate" : ""])
          g.getEdge(player, n2).private(player, ["animate" : ""])
          g.getEdge(player, n3).private(player, ["animate" : ""])
    
          def li = (showScore) ? "<li>How many points they have</li>" : ""
          player.text = c.get("Tutorial4", li)
        }]) 
        
        // Tutorial 5 - Breaking a connection
        a.add(player, [name: "Next", result: { 
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2")
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          
          def e1 = g.getEdge(player, n1)
          def e2 = g.getEdge(player, n2)
          def e3 = g.getEdge(player, n3)
          
          e1.private(player, ["active":-1])
          e2.private(player, ["breaking":1, "active":1, "arrow":n2.id + ",red"])
          e3.private(player, ["active":-1])
                    
          player.text = c.get("Tutorial5")
        }]) 
        
        // Tutorial 6 - Breaking a connection results
        a.add(player, [name: "Next", result: { 
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2")
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          def e1 = g.getEdge(player, n1)
          def e2 = g.getEdge(player, n2)
          def e3 = g.getEdge(player, n3)
          e1.private(player, ["active":0])
          e2.private(player, ["arrow":"", "hidden":1, "active":0])
          e3.private(player, ["active":0])
    
          player.text = c.get("Tutorial6")
        }]) 
        
        // Tutorial 7 - Making a connection description
        a.add(player, [name: "Next", result: {         
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n2 = g.getVertex("dummy_" + playerId + "_2")
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          def n4 = g.getVertex("dummy_" + playerId + "_4")
          def e1 = g.getEdge(player, n1)
          def e3 = g.getEdge(player, n3)
          def e4 = g.addEdge(player, n4)
          
          e1.private(player, ["active":-1])        
          e3.private(player, ["active":-1])
          e4.private(player, ["making":1, "arrow":n4.id + ",green", "active":1])
          
          g.removeConnectedEdge(player, n2)       
                  
          n4.cooperation = 1
          if (showScore) {
            n4.score = practiceScore
          }              
            
          player.text = c.get("Tutorial7")
        }]) 
        
        // Tutorial 8 - Making a connection results
        a.add(player, [name: "Next", result: { 
          
          def n4 = g.getVertex("dummy_" + playerId + "_4") 
          def e4 = g.getEdge(player, n4)
          e4.private(player, ["arrow":"both,green"])
    
          player.text = c.get("Tutorial8", coc, po)
        }]) 

        // TutorialEnd
        a.add(player, [name: "Next", result: { 
          def n1 = g.getVertex("dummy_" + playerId + "_1")
          def n3 = g.getVertex("dummy_" + playerId + "_3")
          def n4 = g.getVertex("dummy_" + playerId + "_4")  
          
          def e1 = g.getEdge(player, n1)
          def e3 = g.getEdge(player, n3)
          def e4 = g.getEdge(player, n4)
          
          e1.private(player, ["active":0])        
          e3.private(player, ["active":0])
          e4.private(player, ["arrow":"", "making":0, "active":0])
          
          def fill0 = ""
          def fill1 = "Start Game"
          if (practiceRounds > 0) {
            fill0 = "<p>Next you will play " + practiceRounds + " practice rounds to familiarize yourself with the game. After these practice rounds your score will be reset. The practice rounds will have no impact on your final score.</p>"
            fill1 = "Start Practice Rounds"
          }
          //
          player.tutorialCompleted = true
          println(g.V.filter{(it.tutorialCompleted == true)}.count() + " Players completed tutorial")

          player.text = c.get("TutorialComplete", fill0, fill1)
        }])
      }
    }//END if(gameStarted)
  }//END if(playerId)
  
  println("Player " + playerId + " joined")
}

onJoinStep.done = { playerId ->
  //println("onJoinStep.done")
}