q1 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Are you female or male?</strong></p>
      <div>
        <input type="radio" name="gender" class="param" ng-model="gender" value="female" required>
        <label for="female"> Female</label><br>
        <input type="radio" name="gender" class="param" ng-model="gender" value="male" required>
        <label for="male"> Male</label>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q1", 
        ["pid": player.id, 
         "gender" : params.gender])
    }]
}

q2 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Could you tell us your age?</strong></p>
      <div>
        <input type="number" name="age" class="param" ng-model="age" required>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q2", 
        ["pid": player.id, 
         "age" : params.age])
    }]
}

q3 = { player->
  return [name: "Next",
    custom: """
      <p><strong>For how many years have you worked in TCS?</strong></p>
      <div>
        <input type="number" name="age" class="param" ng-model="age" required>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q3", 
        ["pid": player.id, 
         "yoe" : params.age])
    }]
}

q4 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Do you want to participate in future studies?</strong></p>
      <div>
        <input type="radio" name="will_participate" class="param" ng-model="will_participate" value="yes" required>
        <label for="yes"> Yes</label><br>
        <input type="radio" name="will_participate" class="param" ng-model="will_participate" value="no" required>
        <label for="no"> No</label>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q4", 
        ["pid": player.id, 
         "will_participate" : params.will_participate])
    }]
}

q5 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Do you think you work in a high performing team</strong></p>
      <div>
        <input type="radio" name="high_performing_team" class="param" ng-model="high_performing_team" value="yes" required>
        <label for="yes"> Yes</label><br>
        <input type="radio" name="high_performing_team" class="param" ng-model="high_performing_team" value="no" required>
        <label for="no"> No</label>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q5", 
        ["pid": player.id, 
         "high_performing_team" : params.high_performing_team])
    }]
}

q6 = { player->
  return [name: "Next",
    custom: """
      <p><strong>What is the highest grade of school or year of college you completed?</strong></p>
      <div>
        <input type="radio" name="highest_grade" class="param" ng-model="highest_grade" value="high_school" required>
        <label for="high_school"> High school (or less)</label><br>
        <input type="radio" name="highest_grade" class="param" ng-model="highest_grade" value="some_college" required>
        <label for="some_college"> Some college (1-3 years)</label><br>
        <input type="radio" name="highest_grade" class="param" ng-model="highest_grade" value="college" required>
        <label for="college"> College graduate (Bachelors)</label><br>
        <input type="radio" name="highest_grade" class="param" ng-model="highest_grade" value="masters" required>
        <label for="masters"> Masters</label><br>
        <input type="radio" name="highest_grade" class="param" ng-model="highest_grade" value="gt_masters" required>
        <label for="gt_masters"> More than a Masters degree</label><br>
        <input type="radio" name="highest_grade" class="param" ng-model="highest_grade" value="other" required>
        <label for="other"> Other</label><br>
        <input ng-if="highest_grade == 'other'" type="text" name="othertext" class="param" ng-model="othertext" required>
      </div>
    """,
    result: { params->
      println(params)
      if (params.highest_grade == "other") {
        a.addEvent("q6", 
          ["pid": player.id, 
           "highest_grade" : params.highest_grade,
           "other" : params.othertext])
      } else {
        a.addEvent("q6", 
          ["pid": player.id, 
           "highest_grade" : params.highest_grade])
      }
    }]
}

q7 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Are you currently--married, widowed, divorced, separated, or have you never been married?</strong></p>
      <div>
        <input type="radio" name="marriage" class="param" ng-model="marriage" value="married" required>
        <label for="married"> Married</label><br>
        <input type="radio" name="marriage" class="param" ng-model="marriage" value="widowed" required>
        <label for="widowed"> Widowed</label><br>
        <input type="radio" name="marriage" class="param" ng-model="marriage" value="divorced" required>
        <label for="divorced"> Divorced</label><br>
        <input type="radio" name="marriage" class="param" ng-model="marriage" value="separated" required>
        <label for="separated"> Separated</label><br>
        <input type="radio" name="marriage" class="param" ng-model="marriage" value="never_married" required>
        <label for="never_married"> Never married</label><br>
        <input type="radio" name="marriage" class="param" ng-model="marriage" value="no_answer" required>
        <label for="no_answer"> Don't want to answer</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q7", 
        ["pid": player.id, 
         "marriage" : params.marriage])
    }]
}

q8 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Would you say that most of the time people try to be helpful, or that they are mostly just looking out for themselves?</strong></p>
      <div>
        <input type="radio" name="reciprocity" class="param" ng-model="reciprocity" value="helpful" required>
        <label for="helpful"> Try to be helpful</label><br>
        <input type="radio" name="reciprocity" class="param" ng-model="reciprocity" value="selfish" required>
        <label for="selfish">  Just look out for themselves</label><br>
        <input type="radio" name="reciprocity" class="param" ng-model="reciprocity" value="depends" required>
        <label for="depends">  Depends</label><br>
        <input type="radio" name="reciprocity" class="param" ng-model="reciprocity" value="dk" required>
        <label for="dk">  Don't know</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q8", 
        ["pid": player.id, 
         "reciprocity" : params.reciprocity])
    }]
}

q9 = { player->
  return [name: "Next",
    custom: """
      <p><strong>How would you rate your health?</strong></p>
      <div>
        <input type="radio" name="health" class="param" ng-model="health" value="excellent" required>
        <label for="excellent"> Excellent</label><br>
        <input type="radio" name="health" class="param" ng-model="health" value="v_good" required>
        <label for="v_good"> Very good</label><br>
        <input type="radio" name="health" class="param" ng-model="health" value="good" required>
        <label for="good"> Good</label><br>
        <input type="radio" name="health" class="param" ng-model="health" value="fair" required>
        <label for="fair"> Fair</label><br>
        <input type="radio" name="health" class="param" ng-model="health" value="poor" required>
        <label for="poor"> Poor</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q9", 
        ["pid": player.id, 
         "health" : params.health])
    }]
}

k6_1 = { player->
  return [name: "Next",
    custom: """
      <p><strong>During the past 30 days, about how often did you feel nervous?</strong></p>
      <div>
        <input type="radio" name="nervous" class="param" ng-model="nervous" value="all" required>
        <label for="all"> All of the time</label><br>
        <input type="radio" name="nervous" class="param" ng-model="nervous" value="most" required>
        <label for="most"> Most of the time</label><br>
        <input type="radio" name="nervous" class="param" ng-model="nervous" value="some" required>
        <label for="some"> Some of the time</label><br>
        <input type="radio" name="nervous" class="param" ng-model="nervous" value="a_little" required>
        <label for="a_little"> A little of the time</label><br>
        <input type="radio" name="nervous" class="param" ng-model="nervous" value="none" required>
        <label for="none"> None of the time</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("k6_1", 
        ["pid": player.id, 
         "nervous" : params.nervous])
    }]
}

k6_2 = { player->
  return [name: "Next",
    custom: """
      <p><strong>During the past 30 days, about how often did you feel hopeless?</strong></p>
      <div>
        <input type="radio" name="hopeless" class="param" ng-model="hopeless" value="all" required>
        <label for="all"> All of the time</label><br>
        <input type="radio" name="hopeless" class="param" ng-model="hopeless" value="most" required>
        <label for="most"> Most of the time</label><br>
        <input type="radio" name="hopeless" class="param" ng-model="hopeless" value="some" required>
        <label for="some"> Some of the time</label><br>
        <input type="radio" name="hopeless" class="param" ng-model="hopeless" value="a_little" required>
        <label for="a_little"> A little of the time</label><br>
        <input type="radio" name="hopeless" class="param" ng-model="hopeless" value="none" required>
        <label for="none"> None of the time</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("k6_2", 
        ["pid": player.id, 
         "hopeless" : params.hopeless])
    }]
}

k6_3 = { player->
  return [name: "Next",
    custom: """
      <p><strong>During the past 30 days, about how often did you feel restless or fidgety?</strong></p>
      <div>
        <input type="radio" name="restless" class="param" ng-model="restless" value="all" required>
        <label for="all"> All of the time</label><br>
        <input type="radio" name="restless" class="param" ng-model="restless" value="most" required>
        <label for="most"> Most of the time</label><br>
        <input type="radio" name="restless" class="param" ng-model="restless" value="some" required>
        <label for="some"> Some of the time</label><br>
        <input type="radio" name="restless" class="param" ng-model="restless" value="a_little" required>
        <label for="a_little"> A little of the time</label><br>
        <input type="radio" name="restless" class="param" ng-model="restless" value="none" required>
        <label for="none"> None of the time</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("k6_3", 
        ["pid": player.id, 
         "restless" : params.restless])
    }]
}

k6_4 = { player->
  return [name: "Next",
    custom: """
      <p><strong>During the past 30 days, about how often did you feel so depressed that nothing could cheer you up?</strong></p>
      <div>
        <input type="radio" name="depressed" class="param" ng-model="depressed" value="all" required>
        <label for="all"> All of the time</label><br>
        <input type="radio" name="depressed" class="param" ng-model="depressed" value="most" required>
        <label for="most"> Most of the time</label><br>
        <input type="radio" name="depressed" class="param" ng-model="depressed" value="some" required>
        <label for="some"> Some of the time</label><br>
        <input type="radio" name="depressed" class="param" ng-model="depressed" value="a_little" required>
        <label for="a_little"> A little of the time</label><br>
        <input type="radio" name="depressed" class="param" ng-model="depressed" value="none" required>
        <label for="none"> None of the time</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("k6_4", 
        ["pid": player.id, 
         "depressed" : params.depressed])
    }]
}

k6_5 = { player->
  return [name: "Next",
    custom: """
      <p><strong>During the past 30 days, about how often did you feel that everything was an effort?</strong></p>
      <div>
        <input type="radio" name="effort" class="param" ng-model="effort" value="all" required>
        <label for="all"> All of the time</label><br>
        <input type="radio" name="effort" class="param" ng-model="effort" value="most" required>
        <label for="most"> Most of the time</label><br>
        <input type="radio" name="effort" class="param" ng-model="effort" value="some" required>
        <label for="some"> Some of the time</label><br>
        <input type="radio" name="effort" class="param" ng-model="effort" value="a_little" required>
        <label for="a_little"> A little of the time</label><br>
        <input type="radio" name="effort" class="param" ng-model="effort" value="none" required>
        <label for="none"> None of the time</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("k6_5", 
        ["pid": player.id, 
         "effort" : params.effort])
    }]
}

k6_6 = { player->
  return [name: "Next",
    custom: """
      <p><strong>During the past 30 days, about how often did you feel worthless?</strong></p>
      <div>
        <input type="radio" name="worthless" class="param" ng-model="worthless" value="all" required>
        <label for="all"> All of the time</label><br>
        <input type="radio" name="worthless" class="param" ng-model="worthless" value="most" required>
        <label for="most"> Most of the time</label><br>
        <input type="radio" name="worthless" class="param" ng-model="worthless" value="some" required>
        <label for="some"> Some of the time</label><br>
        <input type="radio" name="worthless" class="param" ng-model="worthless" value="a_little" required>
        <label for="a_little"> A little of the time</label><br>
        <input type="radio" name="worthless" class="param" ng-model="worthless" value="none" required>
        <label for="none"> None of the time</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("k6_6", 
        ["pid": player.id, 
         "worthless" : params.worthless])
    }]
}

q10 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Do you smoke cigarettes now?</strong></p>
      <div>
        <input type="radio" name="cigarettes" class="param" ng-model="cigarettes" value="yes" required>
        <label for="yes"> Yes</label><br>
        <input type="radio" name="cigarettes" class="param" ng-model="cigarettes" value="no_previous" required>
        <label for="no_previous"> No and previously smoked</label><br>
        <input type="radio" name="cigarettes" class="param" ng-model="cigarettes" value="no_never" required>
        <label for="no_never"> No and never smoked</label><br>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q10", 
        ["pid": player.id, 
         "cigarettes" : params.cigarettes])
    }]
}

q11 = { player->
  return [name: "Next",
    custom: """
      <p><strong>In the last three months, on average, how many days per week have you had any alcohol to drink? (For example, beer, wine)</strong></p>
      <div>
        <input type="number" name="alcohol" class="param" ng-model="alcohol" min="0" max="7" required>
      </div>
    """,
    result: { params->
      println(params)
      a.addEvent("q11", 
        ["pid": player.id, 
         "alcohol" : params.alcohol])
    }]
}

q12 = { player->
  return [name: "Next",
    custom: """
      <p><strong>Could you tell us your height and weight?</strong></p>
      <div>
        <select ng-model="units" required>
          <option value="metric">cms/kgs</option>
          <option value="imperial">ft/in/lbs</option>
        </select> Select units
      </div>
      <div ng-if="units == 'metric'">
        <div>
          <input type="number" name="height_cm" class="param" ng-model="height_cm" min="50" max="300" placeholder="cm" required> Height(cm)
        </div>
        <div>
          <input type="number" name="weight_kg" class="param" ng-model="weight" min="20" max="450" placeholder="kg" required> Weight(kg)
          <input type="hidden" name="units" class="param" value="metric">  
      </div>
      </div>
      </div>
      <div ng-if="units == 'imperial'">
        <div>
          <input type="number" name="height_feet" class="param" ng-model="height_feet" min="2" max="9" placeholder="ft." required> Height(Feet)
        </div>
        <div>
          <input type="number" name="height_inches" class="param" ng-model="height_inches" min="0" max="11" placeholder="in." required> Height(Inches)
        </div>
        <div>
          <input type="number" name="weight_lbs" class="param" ng-model="weight_lbs" min="50" max="1000" placeholder="lbs." required> Weight(Pounds)
          <input type="hidden" name="units" class="param" value="imperial">
        </div>
      </div>
    """,
    result: { params->
      println(params)
      if (params.units == "metric") {
        a.addEvent("q12", 
          ["pid": player.id, 
           "units":params.units,
           "height_cm":params.height_cm,
           "weight_kg":params.weight_kg])
      } else {
        a.addEvent("q12", 
          ["pid": player.id, 
           "units":params.units,
           "height_feet":params.height_feet,
           "height_inches":params.height_inches,
           "weight_lbs" : params.weight_lbs])
      }
    }]
}