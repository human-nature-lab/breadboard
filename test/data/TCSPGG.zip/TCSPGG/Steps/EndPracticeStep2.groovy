endPracticeStep2 = stepFactory.createStep("EndPractice2")

endPracticeStep2.run = {
  println("endPracticeStep2.run: " + curRound)
  curStep = "endPractice2"
  
  //g.random(connectivity)
  // Only connect active players
  Random rand = new Random()
  List players = g.V.filter{it.active == true}.toList()
  int n = players.size()

  for (i in 0..(n - 2)) {
    for (j in i + 1..(n - 1)) {
      def player = players.get(i)
      def neighbor = players.get(j)
      if (rand.nextDouble() < connectivity) {
        g.addTrackedEdge(player, neighbor, "connected")
      }
    }
  }

  g.V.filter{it.active == true}.each { player ->
    
    //player.text = c.get("EndPracticeStep2", (showScore) ? "You may notice that some players have more or less starting points than you. These initial points were assigned at random." : "")
    player.text = c.get("EndPracticeStep2")
    
    a.add(player, [name: "Submit", 
                   custom: """
<p><strong>How do you feel right now?</strong></p>
<input required class="param" type="radio" name="satisfaction" value="v_good"> Very Good<br>
<input required class="param" type="radio" name="satisfaction" value="good"> Good<br>
<input required class="param" type="radio" name="satisfaction" value="neutral"> Neutral<br>
<input required class="param" type="radio" name="satisfaction" value="bad"> Bad<br>
<input required class="param" type="radio" name="satisfaction" value="v_bad"> Very Bad<br>
                           """,
                   result: { params->
                     if (params != null && params.containsKey("satisfaction")) {
                       println(params)
                       a.addEvent("reportSatisfaction", 
                                 ["pid": player.id, 
                                  "step": "endPracticeStep",
                                  "round": (practice) ? "p" + curRound : curRound, 
                                  "satisfaction" : params.satisfaction])
                     }
    	             player.text = player.text + "<p>Press \"Start Game\" to begin.</p>"
                   }])
    
    a.add(player, [name: "Start Game", result: { 
    	player.text =  player.text + c.get("PleaseWait")
    }])
  }
}

endPracticeStep2.done = {
  println("endPracticeStep2.done: " + curRound)
  g.V.filter{it.active == true}.each { player ->
    player.curRound = 1
  }
  cooperationStep.start()
}