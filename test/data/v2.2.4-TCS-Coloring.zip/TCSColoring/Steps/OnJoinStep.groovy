onJoinStep = stepFactory.createNoUserActionStep()

onJoinStep.run = { playerId -> 



  if (playerId && playerId.indexOf("_") == -1 ) {
    def player = g.getVertex(playerId) 
    player.conflicts = 0
    player.ready = false
    player.practiceEnded = false
    player.color = 0
    player.passed = true
    player.returnHit = false
    player.submitHit = false
    player.passTest = false
    player.active = false

    // Validation to prevent players from joining
    // an existing round
    if (!gameStarted) {
      player.text = c.get("WelcomeTCS")

      a.add(player, [name: "Begin Tutorial >", result: { 
        player.active = true
        setupTutorial(player) 
      }])
    } else {
      // we check for player.active and filter out inactive latecomers
      player.text = c.get("GameInProgress")
    }
  } // if (playerId && playerId.indexOf("_") == -1 )

  println "onJoinStep.run"
} //onJoinStep.run

onJoinStep.done = {
  println "onJoinStep.done"
}