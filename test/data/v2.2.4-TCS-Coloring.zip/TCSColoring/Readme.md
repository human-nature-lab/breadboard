# Coloring game for TCS


## To Add AI Players

Run the below before players join

```
g.addVertices(3)
g.V.each { v->
  a.ai.add(v)
}```