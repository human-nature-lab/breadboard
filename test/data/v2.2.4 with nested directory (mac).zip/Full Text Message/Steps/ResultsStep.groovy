import groovy.transform.Field;
resultsStep = stepFactory.createStep()

resultsStep.run = {
  
  g.addTimer(20)
  g.V.filter{!it.active}.each{player ->
  player.timers = [:]
  }
  
     
  println "resultsStep.run"
 g.V.filter{it.active}.each { player ->
    player.text = c.get("ResultsStep",curRound)
   //player.show = player.message
   player.neighbors.filter{it.active}.each{neighbor ->
     player.text += c.get("Message", neighbor.display, neighbor."${player.id}")
   }
    a.add(player, [name: "Next", result: {
      player.text += "<p>Please wait for the other players to click 'Next'.</p>"
    }])
 }
  
  
  
  
  
  }


resultsStep.done = {
  println "resultsStep.done"
  g.V.filter{it.active}.each { player->
      player.timers = [:]
    }
  
  if (curRound < nRounds) {
    curRound++
    messageStep.start()
  } else {
    finalStep.start()
  }
}
