addAI = true // true: add 3 AI, false: add no AI
sequential = true // true: play games sequentially, false: play games in parallel
n = 100 //Max number of players
//nColors = 3 //Number of colors
successBonus = 300 //Bonus given, in cents, if players succeed
gameLength = 300 //300 Time, in seconds, the game lasts
practiceLength = 60 //Length, in seconds, of the practice round
v = 2 //Graph edge parameter
graphType = 3 //1=circle, 2=sw, 3=pref. attach., 4=leadershipCircle, 5=bipartiteRandom
showDegree = false //Whether to show degree on neighbor nodes
maxN = 25 // Players g.t. maxN will be asked to return HIT.
practiceDelay = 1000 // AI delay during practice round

aiStrategy = 2 //1=rand, 2=n col, 3=n deg, 4=col -> deg, 5=fix
aiDelay = 10000 //delay, in ms, between AI choices

if (graphType == 3){
  nColors = 3
}else{
  nColors = 2
}

if (graphType == 5){
  v = 0.35
}

curStep = "init"
gameEnded = false
gameComplete = false
startAt = null

numReady = 0

// Validation Flag
gameStarted = false

def showConflicts(player) {
  player.conflicts = 0
  player.bothE.each { edge->
    if(edge.inV.next().color == edge.outV.next().color) {
      edge.conflict=1
      player.conflicts++
    } else {
      edge.conflict=0
    }
  }
}

def showConflicts() {
  g.E.each { edge->
    if(edge.inV.next().color == edge.outV.next().color) {
      edge.conflict=1
    } else {
      edge.conflict=0
    }
  }	
}

def setupTutorial(player) {
  def neighbor1
  def neighbor2
  def neighbor3
  def neighbor4
  def neighbor5
  // Tutorial 1
  player.private.score = "You"
  player.text = c.get("Tutorial1")

  neighbor1 = g.addVertex(player.id + "_1")
  neighbor1.color = 0
  neighbor1.active = false

  neighbor2 = g.addVertex(player.id + "_2")
  neighbor2.color = 0
  neighbor2.active = false

  neighbor3 = g.addVertex(player.id + "_3")
  neighbor3.color = 0
  neighbor3.active = false

  neighbor4 = g.addVertex(player.id + "_4")
  neighbor4.active = false
  neighbor5 = g.addVertex(player.id + "_5")
  neighbor5.active = false

  g.addEdge(player, neighbor1)
  g.addEdge(player, neighbor2)
  g.addEdge(player, neighbor3) 

  // Tutorial 2
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial2", Math.round(gameLength / 60))
  }])

  // Tutorial 3
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial3")
    player.color = 2
    neighbor1.color = 1
    neighbor2.color = 2
    neighbor3.color = 2
    showConflicts(player)
  }])

  // Tutorial 4
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial4")
    player.color = 1
    neighbor1.color = 2
    neighbor2.color = 2
    neighbor3.color = 2
    showConflicts(player)
  }])

  // Tutorial 5
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial5")
  }])

  // Tutorial 6
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial6")
  }])

  // Tutorial 7
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial7", currency.format(successBonus/100))
  }])

  // Tutorial 8
  a.add(player, [name: "Next >", result: {  
    player.text = c.get("Tutorial8", practiceLength)
    player.color = 0
    neighbor1.color = 0
    neighbor2.color = 0
    neighbor3.color = 0
  }])
  
  //Waiting for a real game
  a.add(player, [name: "Next >", result: { 
    if (startAt == null) {
      startAt = new Date().getTime() + 10000
    }
    player.timer2 = "The game will start in: ," + startAt + ",message"
    player.text = c.get("Waiting")
    //player.ready = true
    player.passTest = true
    player.color = 0
    for (i in 1..5) {
      def neighbor = g.getVertex(player.id + "_" + i)
      if (neighbor != null) {
        g.removePlayer(neighbor.id)
      }     
    }
  },
    event: [
      name: "PlayerWaiting",
      data: [
        pid: player.id  
      ]
    ]
  ])

}