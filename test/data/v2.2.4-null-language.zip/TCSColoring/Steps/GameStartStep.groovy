gameStartStep = stepFactory.createStep()

gameStartStep.run = {
    println("gameStartStep.run")

    numReady = g.V.filter{ it.ready != null && it.ready }.count()

    // Turn off AI behavior here
    g.V.filter { it.ai == 1 }.each { ai ->
        a.ai.add(ai, {})
    }

    // Set up the graph and add AI players
    if (sequential) {
      sequentialGraphStep()
    } else {
      parallelGraphStep()
    }

    g.addTimer(gameLength, "gameEndTimer", "Your bonus is currently ", "down",  "currency", "300", {}, null, "success")

    def evenColor = r.nextInt(2) + 1
    def oddColor = (evenColor == 1) ? 2 : 1

    g.V.filter {
        ((it.ai != null) && (it.ai == 1)) || ((it.active != null) && (it.active) && (it.ready != null) && (it.ready))
    }.each { player ->
        player.text = c.get("GameOn", Math.round(gameLength / 60))
        if (player.ai != null && player.ai == 1 && aiStrategy == 5) {
            // Fixed strategy, adjacent AI should have different colors
            if (graphType == 1 || graphType == 2 || graphType == 4 || graphType == 5) {
                // Ring and SW network, use index to set AI fixed strategy colors
                if (player.even) {
                    player.color = evenColor
                } else {
                    player.color = oddColor
                }
            } else if (graphType == 3) {
                // Pref. Attach. network, use index for color
                player.color = (player.even + 1)
            }
        } else {
            // Random starting color
            player.color = (r.nextInt(nColors) + 1)
        }

        if (showDegree) {
            player.score = player.neighbors.count()
        }
        player.private.score = "You"
        a.addEvent("InitColor",
                ["pid"  : player.id,
                 "color": player.color])
        colorStep(player)
    } // g.V.filter

    def aiGameEnded = (sequential) ? (!addAI) : false
    def humanGameEnded = (sequential) ? addAI : false
    def aiTimer = new Timer()
    def endGameTimer = new Timer()
    def aiGraphTimer = new Timer()
    def humanGraphTimer = new Timer()


    showConflicts()

    a.addEvent("GameStart", ["GameStart": 1])

    use(TimerMethods) {

      aiTimer.runEvery(aiDelay, aiDelay) {
        if (aiStrategy != 5) {
          // Random order
          g.V.filter { (it.ai != null) && (it.ai == 1) && ( (it.aiGraph && !aiGameEnded) || (!it.aiGraph && !humanGameEnded) ) }.shuffle().each { ai ->
            if ((ai != null) && (ai.getProperty("choices"))) {
              
              def choices = ai.getProperty("choices")

              if (r.nextDouble() < aiNoise) { // mutation: randomly pick a color
                def ColorList = [*0..nColors - 1]
                Collections.shuffle(ColorList)
                def choice = choices[ColorList[0]]
                a.choose(choice.uid, null)
              } else {
                def colorObjects = []
                def conflict = false

                for (i in 0..nColors - 1) {
                  colorObjects << [index: i, colorCount: 0, neighborCount: 0]
                }

                ai.neighbors.each { neighbor ->
                  if (neighbor.color == ai.color) {
                    conflict = true
                  }
                  if (neighbor.color > 0) {
                    colorObjects[neighbor.color - 1].colorCount++
                    colorObjects[neighbor.color - 1].neighborCount += neighbor.neighbors.count()
                  }
                } // ai.neighbors.each

                if (conflict) {
                  Collections.shuffle(colorObjects)
                  //1=rand, 2=n col, 3=n deg, 4=col -> deg, 5=fix
                  if (aiStrategy == 2) {
                    colorObjects.sort { it.colorCount }
                  } else if (aiStrategy == 3) {
                    colorObjects.sort { it.neighborCount }
                  } else if (aiStrategy == 4) {
                    colorObjects.sort { color1, color2 -> color1.colorCount <=> color2.colorCount ?: color1.neighborCount <=> color2.neighborCount }
                  }

                  for (colorObject in colorObjects) {
                    if (aiStrategy == 2) {
                      if (colorObject.colorCount < colorObjects.find {
                        it.index == (ai.color - 1)
                      }.colorCount) {
                        def choice = choices[colorObject.index]
                        a.choose(choice.uid, null)
                        break
                      }
                    } else if (aiStrategy == 3) { //need check
                      if (colorObject.neighborCount < colorObjects.find {
                        it.index == (ai.color - 1)
                      }.neighborCount) {
                        def choice = choices[colorObject.index]
                        a.choose(choice.uid, null)
                        break
                      }
                    } else if (aiStrategy == 4) { //need check
                      if ((colorObject.colorCount < colorObjects.find {
                        it.index == (ai.color - 1)
                      }.colorCount) || ((colorObject.colorCount == colorObjects.find {
                        it.index == (ai.color - 1)
                      }.colorCount) && (colorObject.neighborCount < colorObjects.find {
                        it.index == (ai.color - 1)
                      }.neighborCount))) {
                        def choice = choices[colorObject.index]
                        a.choose(choice.uid, null)
                        break
                      }
                    } //if (aiStrategy == 2)
                  } // for (colorObject in colorObjects)
                } // if (conflict)
              } //if (r.nextDouble() < aiNoise)
            } // if ((ai != null) && (ai.getProperty("choices")))
          } // g.V.filter{ it.ai ==1 }.shuffle.each
        } // if (aiStrategy != 5)
      } // task = aiTimer.runEvery(aiDelay, aiDelay)

        gameComplete = false
        def count = 0
        def lastCount = 0

        
        // AI Network
        if (!sequential || addAI) {
          aiGraphTimer.runEvery(100, 100) { // aiGraphTimer.runEvery(1000, 1000)
              //progress bar's value for solved links
              def numEdges = g.E.filter{ it.aiGraph }.toList().size()
              def numConflicts = g.E.filter { it.aiGraph && it.conflict == 1 }.toList().size()
              if (count % 10 == 0) {
                  println("AIGraph: numEdges: " + numEdges + ", numConflicts: " + numConflicts)
              }
              if (count == 0) {
                  g.V.filter {
                      it.aiGraph && (it.active != null) && (it.active) && (it.ready != null) && (it.ready) && ((it.ai == null) || (it.ai != 1))
                  }.each { player ->
                      player.setProperty("progress", numConflicts + "," + numEdges)
                  }
              }
              if (aiGameEnded) {
                  if (count - lastCount > 10) {
                      def bonus = Math.round(successBonus * (gameLength - count / 10) / gameLength) / 100
                      finishGame(aiTimer, aiGraphTimer, c.get("GameWon", currency.format(bonus)), bonus, true, aiGameEnded, humanGameEnded)
                  }
              }
              if (numConflicts == 0) {
                  if (!aiGameEnded) {
                      aiGameEnded = true
                      lastCount = count
                      g.V.filter {
                          it.aiGraph && (it.active != null) && (it.active) && (it.ready != null) && (it.ready) && ((it.ai == null) || (it.ai != 1))
                      }.each { player ->
                          player.setProperty("progress", numConflicts + "," + numEdges)
                      }
                  }
              }
            if (sequential) { count += 1 }
          } // aiGraphTimer.runEvery(100, 100)
        } // if(!sequential || addAi)
      
      
        if (!sequential || !addAI) { 
          // Human Network
          humanGraphTimer.runEvery(100, 100) {
              //progress bar's value for solved links
              def numEdges = g.E.filter{ !it.aiGraph }.toList().size()
              def numConflicts = g.E.filter { !it.aiGraph && it.conflict == 1 }.toList().size()
              if (count % 10 == 0) {
                  println("Human Graph: numEdges: " + numEdges + ", numConflicts: " + numConflicts)
              }
              if (count == 0) {
                  g.V.filter {
                      !it.aiGraph && (it.active != null) && (it.active) && (it.ready != null) && (it.ready) && ((it.ai == null) || (it.ai != 1))
                  }.each { player ->
                      player.setProperty("progress", numConflicts + "," + numEdges)
                  }
              }
              if (humanGameEnded) {
                println("humanGameEnded")
                  if (count - lastCount > 10) {
                      def bonus = Math.round(successBonus * (gameLength - count / 10) / gameLength) / 100
                      finishGame(aiTimer, humanGraphTimer, c.get("GameWon", currency.format(bonus)), bonus, false, aiGameEnded, humanGameEnded)
                  }
              }
              if (numConflicts == 0) {
                println("numConflicts == 0")
                  if (!humanGameEnded) {
                      humanGameEnded = true
                      lastCount = count
                      g.V.filter {
                          !it.aiGraph && (it.active != null) && (it.active) && (it.ready != null) && (it.ready) && ((it.ai == null) || (it.ai != 1))
                      }.each { player ->
                          player.setProperty("progress", numConflicts + "," + numEdges)
                      }
                  }
              }
              count += 1
          } // humanGraphTimer.runEvery(100, 100)
        } // if(!sequential || !addAI)

      } // use (TimerMethods)

    endGameTimer.runAfter(gameLength * 1000) {
      println("endGameTimer.runAfter")
        if (!humanGameEnded) {
            humanGameEnded = true
            finishGame(aiTimer, humanGraphTimer, c.get("GameLost"), 0, false, true, true)
        }
        if (!aiGameEnded) {
            aiGameEnded = true
            finishGame(aiTimer, aiGraphTimer, c.get("GameLost"), 0, true, true, true)
        }
    }
} // gameStartStep.run

gameStartStep.done = {
    println("gameStartStep.done")
}

def finishGame(aiTimer, graphTimer, endText, bonus, isAiGraph, aiGameEnded, humanGameEnded){
    if (aiGameEnded && humanGameEnded) {
      gameEnded = true
      aiTimer.cancel()
      println("endGameTask")
    }
    graphTimer.cancel()

    a.addEvent("GameEnd",["graph": ((isAiGraph) ? "ai" : "human"), "bonus" : bonus, "conflicts" : g.E.filter{ it.aiGraph == isAiGraph && it.conflict == 1 }.toList().size()])

    g.V.filter{ it.aiGraph == isAiGraph }.each { player ->
        a.remove(player)
        player.timers = [:]

        player.text = endText
    }
}