def parallelGraphStep() {
  println("parallelGraphStep.run")
  
  def nAiGraph = (int)Math.floor((numReady + nAi) / 2)
  def nHumanGraph = (int)numReady + nAi - nAiGraph
  
  println("nAiGraph = " + nAiGraph)
  println("nHumanGraph = " + nHumanGraph)
  
  Graph aiGraph = new TinkerGraph();
  for (int i = 0; i < nAiGraph; i++) { //for (int i = 0; i < n; i++) {
    aiGraph.addVertex(i)
  }
  
  Graph humanGraph = new TinkerGraph();
  for (int i = 0; i < nHumanGraph; i++) { //for (int i = 0; i < n; i++) {
    humanGraph.addVertex(i)
  }
  
  barbasiAlbert(aiGraph)
  barbasiAlbert(humanGraph)
  
  // Record degree of aiGraph vertices
  aiGraph.V.each { v ->
    v.degree = v.neighbors.count()
  }
  
  def players = g.V.shuffle.toList()
  
  // Assign player IDs to aiGraph vertices	
  def aiGraphVertices = aiGraph.V.toList()
  if (aiPlacement == 2) { // High degree
    aiGraphVertices = aiGraph.V.sort{ it.degree }.reverse().toList()
  } 
  if (aiPlacement == 3) { // Low degree
    aiGraphVertices = aiGraph.V.sort{ it.degree }.toList()
  }

  for (int i = 0; i < nAiGraph; i++) {
    if (i < nAi) {
      
      def aiId = "AI_" + (i+1)
      g.addAIPlayer(a, aiId, {})
      if (graphType == 1 || graphType == 2 || graphType == 3 || graphType == 4 || graphType == 5) {
        g.getVertex(aiId).even = aiGraphVertices.get(i).even
      }
      g.getVertex(aiId).aiGraph = true
      aiGraphVertices.get(i).realId = aiId
      println("Assigning AI " + aiId + " to vertice with degree " + aiGraphVertices.get(i).degree)
    } else {
      def p = players.get(i-nAi) 
      aiGraphVertices.get(i).realId = p.id
      p.aiGraph = true
      println("Assigning player " + p.id + " to vertice with degree " + aiGraphVertices.get(i).degree)
    }
  }
  
  // Add edges
  aiGraph.E.each { tempEdge ->
    g.addTrackedEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId), "connected")
    g.getEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId)).aiGraph = true
  }
  
  // Assign remaining player IDs to humanGraph vertices
  def humanGraphVertices = humanGraph.V.toList()
  
  for (int j = nAiGraph; j < (numReady + nAi); j++) {
    def p = players.get(j-nAi) 
    p.aiGraph = false
    humanGraphVertices.get(j-nAiGraph).realId = p.id
    println("Assigning player " + p.id + " to human graph.")
  }
  
  // Add edges
  humanGraph.E.each { tempEdge ->
    g.addTrackedEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId), "connected")
    g.getEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId)).aiGraph = false
  }
}

def sequentialGraphStep() {
  println("sequentialGraphStep.run")
  
  def nPlayers = numReady
  if(addAI) {
    nPlayers += nAi
  }
  
  println("nPlayers = " + nPlayers)
  
  Graph graph = new TinkerGraph();
  for (int i = 0; i < nPlayers; i++) { 
    graph.addVertex(i)
  }
  
  barbasiAlbert(graph)
  
  // Record degree of aiGraph vertices
  graph.V.each { v ->
    v.degree = v.neighbors.count()
  }
  
  def players = g.V.filter{ it.active }.shuffle.toList()
  
  // Assign player IDs to aiGraph vertices	
  def graphVertices = graph.V.toList()
  if (aiPlacement == 2) { // High degree
    graphVertices = graph.V.sort{ it.degree }.reverse().toList()
  } 
  if (aiPlacement == 3) { // Low degree
    graphVertices = graph.V.sort{ it.degree }.toList()
  }

  for (int i = 0; i < nPlayers; i++) {
    if (addAI && i < nAi) {
      
      def aiId = "AI_" + (i+1)
      g.addAIPlayer(a, aiId, {})
      if (graphType == 1 || graphType == 2 || graphType == 3 || graphType == 4 || graphType == 5) {
        g.getVertex(aiId).even = graphVertices.get(i).even
      }
      g.getVertex(aiId).aiGraph = addAI
      graphVertices.get(i).realId = aiId
      println("Assigning AI " + aiId + " to vertice with degree " + graphVertices.get(i).degree)
    } else {
      def p = (addAI) ? players.get(i-nAi) : players.get(i) 
      graphVertices.get(i).realId = p.id
      p.aiGraph = addAI
      println("Assigning player " + p.id + " to vertice with degree " + graphVertices.get(i).degree)
    }
  }
  
  // Add edges
  graph.E.each { tempEdge ->
    g.addTrackedEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId), "connected")
    g.getEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId)).aiGraph = addAI
  }
  
}


def ring(graph) {
  List players = graph.getVertices().iterator().toList()

  //Collections.shuffle(players)

  for (i in 0..(n-1)) {
    def p = players.get(i)
    p.setProperty("even", (i % 2 == 0))
    //p.index = i
    graph.addEdge(p, players.get((i + 1) % n), "connected")
  }
}

def smallWorldColoring(graph) {
  ring(graph)
  def edgesAdded = 0
  List players = graph.getVertices().iterator().toList()
  Random rand = new Random()
  while (edgesAdded < v) {
    def p1 = players.get(rand.nextInt(players.size()))
    def p2 = players.get(rand.nextInt(players.size()))
    if ((p1 != p2) && (! p1.both.retain([p2]).hasNext()) && (p1.even != p2.even)) {
      graph.addEdge(p1, p2, "connected")
      edgesAdded++
    }
  }
}

def leadershipRing(graph){
  
  List players = graph.getVertices().iterator().toList()
  def p0 = players.get(n-2)
  def p1 = players.get(n-1)
  p0.setProperty("even", true)
  p1.setProperty("even", false)
  
  for (i in 0..(n-3)) { //(0..n-1)
    def p = players.get(i)
    p.setProperty("even", (i % 2 == 0))
    //p.index = i
    graph.addEdge(p, players.get((i + 1) % (n-2)), "connected")
    if (i % 2 == 0){
      graph.addEdge(p, p1, "connected")
    }else{
      graph.addEdge(p, p0, "connected")
    }                    
  }  
}

def barbasiAlbert(graph) {
  Random rand = new Random()

  def neighborList = [] //Target vertices for new edges.  The array size is always v.
  def inNetwork = [] //Array with each vertex added once per degree
  def colors = 0..v // Possible color list to avoid neighbors
  graph.V.shuffle.eachWithIndex { player, i->
    //If we've already added v players to the inNetwork array
    if (i >= v) {
      neighborList.each { neighbor->
        if (colors.contains(neighbor.even)){
        	colors -= neighbor.even
        }
      }
      player.even = colors.get(rand.nextInt(colors.size()))
      colors = 0..v
      
      neighborList.each { neighbor->
        graph.addEdge(player, neighbor, "connected")
        inNetwork << neighbor
        inNetwork << player
      }
      

      //Now choose v unique vertices from the existing vertices
      //Pick uniformly from inNetwork (preferential attachment)
      neighborList = []
      def keyList = []
      while (neighborList.size() < v) {
        def key = rand.nextInt(inNetwork.size()) //Select the array key for inNetwork randomly
        if ( ( !keyList.contains(key) ) && ( !neighborList.contains( inNetwork.get(key) ) ) ) { //Avoid previously picked-up keys
          neighborList << inNetwork.get(key)
          keyList << key
        } 
      }
    } else {
      player.even = rand.nextInt(v + 1)      
      
      if (neighborList.size() > 0){
        neighborList.each { neighbor->
        	graph.addEdge(player, neighbor, "connected")
        }
      }
      neighborList << player //Initial neighbors
    }
  }
}

def bipartiteRandom(graph){
  List players = graph.getVertices().iterator().toList()
  Random rand = new Random()
  def neighborList = []
  while (neighborList.size() < n){
    graph.getEdges().each({
      graph.removeEdge(it)
    })
    neighborList = []
  	def even = []
  	def odd = []
  	for (i in 0..(n-1)){
  		def p = players.get(i)
    	p.setProperty("even", (i % 2 == 0))
    	if (i % 2 == 0){
      		even << i
    	}else{
      		odd << i
    	}
  	}
  	for (i in even){
    	for (j in odd){
      		if (rand.nextDouble() < v){
        		def p1 = players.get(i)
    			def p2 = players.get(j)
        		graph.addEdge(p1, p2, "connected") 
              	if (!neighborList.contains(i)){
                	neighborList << i
                }
              	if (!neighborList.contains(j)){
                	neighborList << j
                }
      		}
    	}
  	}
    println neighborList.size()
  }
}

def barbasiAlbertFromEdgelist(graph, n, isHard){
  List players = graph.getVertices().iterator().toList()
  
  def filename = "csv/n" + n + "_" + ((isHard) ? "hard" : "easy") + ".csv"
  def count = 0
  new File(filename).splitEachLine(","){line->
    def p1 = players.get(line[0].toInteger())
    def p2 = players.get(line[1].toInteger())
    graph.addEdge(p1, p2, "connected")     
        
  }
  for (i in 0..(n - 1)) {
    def p = players.get(i.toInteger())
    p.setProperty("even", (i % 2 == 0))
  }
  
}