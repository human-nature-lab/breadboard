initStep = stepFactory.createStep()

initStep.run = {
  println("initStep.run")

  // Flag start of game
  gameStarted = true
    
  // record initial parameters in data here
  a.addEvent("InitParameters", 
  ["n" : n,
   "nColors" : nColors,
   "successBonus" : successBonus,
   "gameLength" : gameLength,
   "aiDelay" : aiDelay,
   "practiceLength" : practiceLength,
   "v" : v,
   "graphType" : graphType,
   "aiStrategy" : aiStrategy,
   "showDegree" : showDegree,
   "nAi" : nAi,
   "aiPlacement" : aiPlacement,
   "aiNoise" : aiNoise])
  
  g.V.filter{ (it.active != null) && (it.active)}.each { player->
    player.setProperty("timer", "")
    player.setProperty("timer2", "")
    if (player.passTest == true){
      a.add(player, [name: "Ready", result: { 
        player.ready = true
        player.text += "<p><strong>Please wait... the game will start momentarily.</strong></p>"
      },
        event: [
          name: "PlayerReady",
          data: [
            pid: player.id  
          ]
        ]
      ])
    }
  } 
} // initStep.run

initStep.done = {
  println("initStep.done")
  gameStartStep.start()
}