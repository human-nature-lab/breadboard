import groovy.transform.Field;
messageStep = stepFactory.createStep()

messageStep.run = {

println "messageStep.run: ${curRound}"
g.addTimer(45)
println "Message Timer added"  
g.V.filter{!it.active}.each{player ->
  player.timers = [:]
  }  
  

  if(curRound ==1){
@Field def messageTimer =  new Timer() 
  messageTimer.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}
  }
  else if(curRound == 2){
     @Field def messageTimer1 =  new Timer()
    messageTimer1.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)  
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }
  else if(curRound == 3){
     @Field def messageTimer2 =  new Timer()
    messageTimer2.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }
  else if(curRound == 4){
     @Field def messageTimer3 =  new Timer() 
    messageTimer3.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }
  else if(curRound == 5){
     @Field def messageTimer4 =  new Timer()
    messageTimer4.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }
  else if(curRound == 6){
     @Field def messageTimer5 =  new Timer() 
    messageTimer5.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }
  else if(curRound == 7){
     @Field def messageTimer6 =  new Timer() 
    messageTimer6.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }
else if(curRound == 8){
     @Field def messageTimer7 =  new Timer() 
    messageTimer7.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }  
else if(curRound == 9){
     @Field def messageTimer8 =  new Timer() 
    messageTimer8.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }  
else if(curRound == 10){
     @Field def messageTimer9 =  new Timer() 
    messageTimer9.runAfter(45000){
  g.V.filter{it.active}.each{ player->
    if(player.action == false){
    a.addEvent("DropPlayer", ["pid": (player.id)])
  	player.text = c.get("Dropped")
  	player.active = false
  	player.dropped = true
    g.getSubmitForm(player, 0, true)
  	a.remove(player.id)
  	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
  }  
}
   
}

  }  
    
  g.V.filter{it.active}.each { player->
    def customInputs = ""
    player.text = c.get("MessageStep",curRound)
    player.action = false
    player.neighbors.each{neighbor ->  
    customInputs += """<span Neighbor ${neighbor.display} style="display:inline-block">
	 <label style="display:block">Neighbor ${neighbor.display}</label> 
<textarea  name="textinput${neighbor.id}" rows="10" cols="10" class="param" ng-model="textinput${neighbor.id}" required></textarea>
</span> """.toString()
     }
 
    a.add(player, [name: "Submit",
    custom: customInputs,
    result: { params->
      println(params)
      player.neighbors.each{neighbor ->
      println(groovy.json.StringEscapeUtils.escapeJavaScript(params."textinput${neighbor.id}".toString()))
      player."${neighbor.id}" = groovy.json.StringEscapeUtils.escapeJavaScript(params."textinput${neighbor.id}".toString())  
      player.action =true
      a.addEvent("sentMessage",["pid":player.id,
	 "nid":neighbor.id,
	 "message":player."${neighbor.id}", "round": curRound]) 
      println "JS Clean"
       
        
      }
      player.text += "<p>Please wait for the other players to make their choices.</p>"
    }])
   
  }
}
  






messageStep.done = {
	println "messageStep.done: ${curRound}"
  	g.V.filter{it.active}.each { player->
      player.timers = [:]
    }
  if(curRound == 1){
  	messageTimer.cancel()
  }else if(curRound == 2){
    messageTimer1.cancel()
  }else if(curRound == 3){
    messageTimer2.cancel()
  }else if(curRound == 4){
    messageTimer3.cancel()
  }else if(curRound == 5){
    messageTimer4.cancel()
  }else if(curRound == 6){
    messageTimer5.cancel()
  }else if(curRound == 7){
    messageTimer6.cancel()
  }else if(curRound == 8){
    messageTimer7.cancel()
  }else if(curRound == 9){
    messageTimer8.cancel()
  }else if(curRound == 10){
    messageTimer9.cancel()
  }
  	resultsStep.start()
}


// <input type="text" name="textinput" class="param" ng-model="textinput" required>
// <textarea  name="textinput" rows="10" cols="10" class="param" ng-model="textinput" required></textarea>
// <input type="number" name="textinput" min="0" max="20" step="1" class="param" ng-model="textinput" required>