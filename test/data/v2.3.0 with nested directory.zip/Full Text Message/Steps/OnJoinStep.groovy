onJoinStep = stepFactory.createNoUserActionStep()

onJoinStep.run = { playerId->
  def player = g.getVertex(playerId)

  player.active = true // Active players have not been dropped
  player.message = 0
  player.display = player.id.take(4)
  
  player.text = c.get("Welcome")
  a.add(player, [name: "Next", result: {
    player.text = c.get("Tutorial1")
  }])
  a.add(player, [name: "Next", result: {
    player.text = c.get("Tutorial4",nRounds)
  }])
    
  a.add(player, [name: "Next", result: {
    player.text = c.get("Tutorial3")
  }])
  
    a.add(player, [name: "Next", result: {
    player.text = c.get("Quiz1")
  }])
  
    a.add(player, [name: "Submit",
    custom:"""<span Q1 style="display:inline-block">
	 <label style="display:block"> When will you recieve the bonus?</label> 
<input type ="radio"  name="Q1" class="param" value ="a" ng-model="Q1" checked> a) My neighbors and I attack at the same time but not everyone does.<br>
<input type ="radio"  name="Q1" class="param" value ="b" ng-model="Q1"> b) Most players attack at the same time but not everybody.<br>
<input type ="radio"  name="Q1" class="param" value ="c" ng-model="Q1"> c) All players attack at the same time.
</span> """,
    result: { params->
      player.Q1 = params.Q1.value.toString()
      a.addEvent("Q1",["pid":player.id,
	  "choice": player.Q1]) 
      player.text = c.get("Quiz2")
    }])
  
  a.add(player, [name: "Submit",
    custom:"""<span Q2 style="display:inline-block">
	 <label style="display:block"> What kinds of messages can you send?</label> 
<input type ="radio"  name="Q2" class="param" value ="a" ng-model="Q2" checked> a) Only numbers.<br>
<input type ="radio"  name="Q2" class="param" value ="b" ng-model="Q2"> b) Any plaintext message.<br>
<input type ="radio"  name="Q2" class="param" value ="c" ng-model="Q2"> c) Only one word.
</span> """,
    result: { params->
      player.Q2 = params.Q2.value.toString()
      a.addEvent("Q2",["pid":player.id,
	  "choice": player.Q2]) 
      player.text = c.get("Quiz3")
    }])
  
  a.add(player, [name: "Submit",
    custom:"""<span Q3 style="display:inline-block">
	 <label style="display:block"> What happens if a player does not complete the Message Step in the allotted time?</label> 
<input type ="radio"  name="Q3" class="param" value ="a" ng-model="Q3" checked> a) The player is dropped from the game.<br>
<input type ="radio"  name="Q3" class="param" value ="b" ng-model="Q3"> b) The player is not dropped from the game.
</span> """,
    result: { params->
      player.Q3 = params.Q3.value.toString()
      a.addEvent("Q3",["pid":player.id,
	  "choice": player.Q3]) 
        player.text = c.get("PleaseWait")     
    }])
      

}
      
      
onJoinStep.done = {
  
}